"""
tool_server_agent_patch.py

Drop this block into server/tool_server.py — add it right after the existing
/learn endpoint (around line 1050), before the `if __name__ == "__main__":` block.

You also need two additions at the TOP of tool_server.py:

1. After the existing imports, add:
       import sys, os
       sys.path.insert(0, os.path.dirname(__file__))
       from agents import run_agent, should_use_agent, route_command

2. That's it — no other changes to tool_server.py.

────────────────────────────────────────────────────────────────────────────────
PASTE THE BLOCK BELOW INTO tool_server.py:
────────────────────────────────────────────────────────────────────────────────
"""

AGENT_ENDPOINT_CODE = '''
# ── Agent endpoint ─────────────────────────────────────────────────────────

@app.route("/agent", methods=["POST"])
def agent_endpoint():
    """
    Execute a command via the domain agent system.

    Request JSON:
        {
            "command": "open my SIH 2025 PDF and summarize it",
            "context": { ...ACTIVE_CONTEXT snapshot... }   // optional
        }

    Response JSON:
        {
            "success": true,
            "summary": "Opening SIH 2025 problem statement.",
            "steps_taken": 2,
            "tool_calls": ["find_file", "open_file"],
            "error": null
        }
    """
    data = request.get_json(force=True)
    if not data or "command" not in data:
        return jsonify({"error": "Missing 'command' field"}), 400

    command = data["command"].strip()
    if not command:
        return jsonify({"error": "Empty command"}), 400

    # Use caller-provided context or fall back to live ACTIVE_CONTEXT
    context = data.get("context") or dict(ACTIVE_CONTEXT)

    try:
        result = run_agent(command, context)
        return jsonify({
            "success":     result.success,
            "summary":     result.summary,
            "steps_taken": result.steps_taken,
            "tool_calls":  result.tool_calls,
            "error":       result.error,
            "data":        result.data,
        })
    except Exception as e:
        logger.exception(f"[/agent] Unhandled error: {e}")
        return jsonify({
            "success":     False,
            "summary":     "An internal error occurred in the agent system.",
            "steps_taken": 0,
            "tool_calls":  [],
            "error":       str(e),
        }), 500


@app.route("/agent/route", methods=["POST"])
def agent_route_debug():
    """
    Debug endpoint — returns which agent would handle a command and its scores.

    Request JSON:  {"command": "..."}
    Response JSON: {"domain": "browser", "should_use_agent": true, "scores": {...}}
    """
    data = request.get_json(force=True)
    command = data.get("command", "")

    from agents import route_command, should_use_agent, get_dispatcher
    dispatcher = get_dispatcher()

    return jsonify({
        "domain":           route_command(command),
        "should_use_agent": should_use_agent(command),
        "scores":           dispatcher.route_with_scores(command),
    })
'''

# Print the patch for easy copy-paste
if __name__ == "__main__":
    print(AGENT_ENDPOINT_CODE)
