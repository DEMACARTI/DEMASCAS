"""
system_agent.py — macOS UI and application control for DEMASCAS.

Handles: app open/close/switch, UI element interaction, keyboard shortcuts,
screen reading (accessibility tree), clipboard, volume/brightness controls.

Key behaviors:
- Prefers keyboard shortcuts over click automation when possible (faster + safer)
- Uses accessibility tree before attempting visual/VLM clicks
- Never force-quits without checking if app is actually open
- Captures screen state after every UI mutation for feedback
"""

import re
import logging
from .base_agent import AgentBase, AgentResult, StepRecord

logger = logging.getLogger(__name__)

# Common macOS app name normalizations
APP_ALIASES = {
    "chrome": "Google Chrome",
    "firefox": "Firefox",
    "safari": "Safari",
    "brave": "Brave Browser",
    "terminal": "Terminal",
    "vscode": "Visual Studio Code",
    "code": "Visual Studio Code",
    "finder": "Finder",
    "spotify": "Spotify",
    "slack": "Slack",
    "zoom": "Zoom",
    "notes": "Notes",
    "calendar": "Calendar",
    "mail": "Mail",
    "photos": "Photos",
    "preview": "Preview",
    "xcode": "Xcode",
}


class SystemAgent(AgentBase):
    domain_name = "system"

    tool_names = [
        # App control
        "open_application",
        "quit_application",
        "activate_application",
        "list_running_applications",
        "wait_for_app_ready",
        # UI interaction
        "click_ui_element",
        "type_text",
        "type_text_into_element",
        "scroll_direction",
        "drag_element",
        "find_and_click",
        "right_click_element",
        "type_and_submit",
        "scroll_to_element",
        "wait_for_element",
        # Keyboard
        "press_keyboard_shortcut",
        # Screen reading
        "get_active_window_tree",
        "list_open_windows",
        # Clipboard
        "get_clipboard",
        "set_clipboard",
        # Vision (fallback)
        "vision_execute",
    ]

    @property
    def system_prompt(self) -> str:
        return """You are DEMASCAS's System Agent — a specialist in macOS UI automation and app control.

Your responsibilities:
- Opening, quitting, and switching between applications
- Clicking UI elements and typing text
- Pressing keyboard shortcuts
- Reading the accessibility tree to understand screen state
- Clipboard operations

SYSTEM RULES:
1. Prefer press_keyboard_shortcut over click_ui_element when a shortcut exists (faster, more reliable).
2. Before clicking a UI element, use get_active_window_tree to confirm it exists.
3. Use activate_application before interacting with an app's UI elements.
4. NEVER force-quit system-critical apps (Finder, SystemUIServer, Dock).
5. For typing into a specific field: use type_text_into_element, not just type_text.
6. After clicking or typing, wait for the UI to respond before the next step.
7. For volume/brightness: use press_keyboard_shortcut (F1/F2 for brightness, F10-F12 for volume).
8. If a UI element can't be found in the accessibility tree, try find_and_click or vision_execute as fallback.
9. When asked "what's on screen": use get_active_window_tree and summarize the key elements.
10. list_running_applications returns all open apps — use it when you need to know what's running."""

    def _extra_rules(self) -> str:
        return """11. Keyboard shortcut format: "cmd+c", "cmd+shift+4", "f11", "volume_up".
12. For "copy": press_keyboard_shortcut with keys="cmd+c".
13. For "paste": press_keyboard_shortcut with keys="cmd+v".
14. For "screenshot": press_keyboard_shortcut with keys="cmd+shift+3" (full) or "cmd+shift+4" (selection)."""

    def run(self, goal: str, context: dict) -> AgentResult:
        goal_lower = goal.lower()

        # Fast-path: single app open
        app = self._extract_app_open(goal_lower)
        if app:
            return self._app_open_flow(app, context)

        # Fast-path: single app quit
        app = self._extract_app_close(goal_lower)
        if app:
            return self._app_close_flow(app, context)

        # Fast-path: clipboard read
        if re.search(r"\b(what's in|what is in|read|show)\b.*clipboard", goal_lower):
            return self._clipboard_read_flow(context)

        # Fast-path: screen read
        if re.search(r"\b(what('s| is) on (the )?screen|what (do you|can you) see|describe (the )?screen)\b", goal_lower):
            return self._screen_read_flow(context)

        # General system task
        return self._execute(goal, context)

    # ── Specialized sub-flows ─────────────────────────────────────────────────

    def _app_open_flow(self, app_name: str, context: dict) -> AgentResult:
        """Directly open an application."""
        normalized = APP_ALIASES.get(app_name.lower(), app_name)
        result = self._call_tool("open_application", {"app_name": normalized})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary=f"I couldn't open {normalized}. {result}",
                steps_taken=1,
                tool_calls=["open_application"]
            )
        return AgentResult(
            success=True,
            summary=f"Opening {normalized}.",
            steps_taken=1,
            tool_calls=["open_application"]
        )

    def _app_close_flow(self, app_name: str, context: dict) -> AgentResult:
        """Directly quit an application."""
        normalized = APP_ALIASES.get(app_name.lower(), app_name)

        # Safety: don't quit Finder
        if normalized.lower() == "finder":
            return AgentResult(
                success=False,
                summary="I can't quit Finder — macOS requires it to stay running.",
                steps_taken=0,
                tool_calls=[]
            )

        result = self._call_tool("quit_application", {"app_name": normalized})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary=f"I couldn't quit {normalized}. It may not be running.",
                steps_taken=1,
                tool_calls=["quit_application"]
            )
        return AgentResult(
            success=True,
            summary=f"Quit {normalized}.",
            steps_taken=1,
            tool_calls=["quit_application"]
        )

    def _clipboard_read_flow(self, context: dict) -> AgentResult:
        """Read and report clipboard contents."""
        result = self._call_tool("get_clipboard", {})
        if self._is_tool_error(result) or not result.strip():
            return AgentResult(
                success=True,
                summary="Your clipboard is empty.",
                steps_taken=1,
                tool_calls=["get_clipboard"]
            )
        preview = result[:200]
        return AgentResult(
            success=True,
            summary=f"Your clipboard contains: {preview}",
            steps_taken=1,
            tool_calls=["get_clipboard"]
        )

    def _screen_read_flow(self, context: dict) -> AgentResult:
        """Read and summarize what's on screen."""
        result = self._call_tool("get_active_window_tree", {})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary="I couldn't read the screen right now.",
                steps_taken=1,
                tool_calls=["get_active_window_tree"]
            )

        # Build a natural spoken summary from the tree
        lines = result.split("\n")
        app_line = next((l for l in lines if "ACTIVE APP:" in l), "")
        app_name = app_line.replace("ACTIVE APP:", "").strip() if app_line else "an app"

        # Count interactive elements
        buttons = len([l for l in lines if "[button]" in l])
        inputs  = len([l for l in lines if "[text field]" in l or "[input]" in l])

        summary = f"You're looking at {app_name}."
        if buttons > 0:
            summary += f" I can see {buttons} button{'s' if buttons != 1 else ''}."
        if inputs > 0:
            summary += f" There {'are' if inputs != 1 else 'is'} {inputs} text field{'s' if inputs != 1 else ''}."

        return AgentResult(
            success=True,
            summary=summary,
            steps_taken=1,
            tool_calls=["get_active_window_tree"]
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _extract_app_open(self, goal_lower: str) -> str:
        """Extract app name from 'open X' / 'launch X' commands. Returns "" if not a simple open."""
        m = re.match(r"^(?:open|launch|start)\s+(.+)$", goal_lower.strip())
        if not m:
            return ""
        candidate = m.group(1).strip()
        # Reject if it looks like a file (has extension) or URL
        if re.search(r"\.(pdf|docx|xlsx|pptx|txt|html|com|org|io)$", candidate):
            return ""
        if "." in candidate and len(candidate.split(".")) == 2:
            return ""
        return candidate

    def _extract_app_close(self, goal_lower: str) -> str:
        """Extract app name from 'quit X' / 'close X' commands."""
        m = re.match(r"^(?:quit|close|exit|kill)\s+(.+)$", goal_lower.strip())
        if not m:
            return ""
        return m.group(1).strip()

    def _on_step_complete(self, record: StepRecord) -> None:
        """Track active app after open/activate."""
        if record.tool in ("open_application", "activate_application") and record.success:
            # Extract app name from args
            app = record.args.get("app_name", "")
            if app:
                self._active_context["active_app"] = app
