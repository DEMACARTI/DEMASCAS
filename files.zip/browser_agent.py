"""
browser_agent.py — Autonomous browser control for DEMASCAS.

Handles: Gmail (read, compose, reply), general web browsing,
YouTube search and playback, e-commerce search, web forms.

Key behaviors:
- Always checks web_memory for known selectors before DOM scanning
- Handles cookie banners, popups, login prompts automatically
- Never auto-sends emails — always composes a draft
- Obstacle detection runs before any meaningful page interaction
"""

import logging
from .base_agent import AgentBase, AgentResult, StepRecord

logger = logging.getLogger(__name__)


class BrowserAgent(AgentBase):
    domain_name = "browser"

    tool_names = [
        # Navigation
        "open_url",
        "open_url_and_wait",
        # Page reading
        "browser_get_url",
        "browser_get_title",
        "browser_get_page_text",
        "browser_get_dom_summary",
        "browser_navigate",
        "browser_navigate_and_wait",
        "browser_back",
        "browser_reload",
        # Interaction
        "browser_click",
        "browser_click_text",
        "browser_type",
        "browser_type_by_label",
        "browser_press_key",
        "browser_scroll",
        "browser_fill_form",
        "browser_select_option",
        "browser_submit_form",
        # Tab management
        "browser_new_tab",
        "browser_close_tab",
        "browser_list_tabs",
        "browser_switch_to_tab",
        # Gmail
        "gmail_compose_draft",
        "gmail_read_email",
        # Web agent (higher-level)
        "web_analyze_page",
        "web_smart_click",
        "web_scan_for_obstacles",
        "web_handle_obstacle",
        "web_search",
        "web_read_article",
        "web_youtube_search",
        "web_youtube_play_first",
        "web_ecommerce_search",
        # Clipboard (for copy-paste in browser)
        "get_clipboard",
        "set_clipboard",
        # Keyboard (for shortcuts in browser)
        "press_keyboard_shortcut",
    ]

    @property
    def system_prompt(self) -> str:
        return """You are DEMASCAS's Browser Agent — a specialist in controlling Brave Browser on macOS.

Your responsibilities:
- Web navigation and browsing
- Gmail: read emails, compose drafts, smart reply
- YouTube: search and play videos
- E-commerce: product search and comparison
- Web forms: fill and submit
- Web research: navigate to pages, extract content

BROWSER-SPECIFIC RULES:
1. Brave Browser's accessibility tree CANNOT see web page content. Use browser_get_dom_summary instead.
2. For Gmail (mail.google.com): use gmail_compose_draft directly — it handles the whole compose flow.
3. NEVER auto-send emails. gmail_compose_draft opens a draft only.
4. Before clicking anything important, run web_scan_for_obstacles first to detect popups/banners.
5. If you see a cookie banner or popup, use web_handle_obstacle to dismiss it before proceeding.
6. For YouTube: use web_youtube_search then web_youtube_play_first.
7. For general web search: use web_search (opens DuckDuckGo), then web_read_article for full content.
8. When a page has a login wall or paywall: STOP and tell the user — never attempt to bypass it.
9. Prefer browser_click_text over browser_click when you know the visible text of the element.
10. After navigating, wait 1-2 seconds before interacting — use open_url_and_wait for this."""

    def _extra_rules(self) -> str:
        return """11. If current URL is mail.google.com → you are in Gmail. Prioritize gmail_* tools.
12. To scroll on a web page use browser_scroll, not press_keyboard_shortcut.
13. When reading articles: web_read_article is faster than browser_get_page_text."""

    def run(self, goal: str, context: dict) -> AgentResult:
        """
        Route to specialized sub-flows where possible,
        otherwise fall through to the general step loop.
        """
        goal_lower = goal.lower()

        # Gmail compose fast-path
        if any(kw in goal_lower for kw in ["compose email", "write email", "draft email",
                                             "send email", "email to"]):
            return self._gmail_compose_flow(goal, context)

        # Gmail read fast-path
        if any(kw in goal_lower for kw in ["read email", "check email", "what did",
                                             "any emails", "new emails", "inbox"]):
            return self._gmail_read_flow(goal, context)

        # YouTube fast-path
        if any(kw in goal_lower for kw in ["youtube", "watch", "play video", "play music"]):
            return self._youtube_flow(goal, context)

        # General browsing — use full step loop
        return self._execute(goal, context)

    # ── Specialized sub-flows ─────────────────────────────────────────────────

    def _gmail_compose_flow(self, goal: str, context: dict) -> AgentResult:
        """
        Direct path for email composition.
        Extracts to/subject/body from goal using LLM, then calls gmail_compose_draft.
        """
        # First open Gmail if not already there
        current_url = context.get("active_url", "")
        if "mail.google.com" not in current_url:
            self._call_tool("open_url_and_wait", {"url": "https://mail.google.com", "wait_time": 3})

        # Use the general step loop with Gmail-specific context injected
        self._active_context = {
            **context,
            "active_url": "https://mail.google.com",
            "active_app": "Brave Browser",
            "task_hint": "You are composing an email. Use gmail_compose_draft with to, subject, body args extracted from the user's goal. All args are optional — fill what you know.",
        }
        return self._execute(goal, self._active_context)

    def _gmail_read_flow(self, goal: str, context: dict) -> AgentResult:
        """Read/check email flow."""
        current_url = context.get("active_url", "")
        if "mail.google.com" not in current_url:
            self._call_tool("open_url_and_wait", {"url": "https://mail.google.com", "wait_time": 3})

        self._active_context = {
            **context,
            "active_url": "https://mail.google.com",
            "active_app": "Brave Browser",
        }
        return self._execute(goal, self._active_context)

    def _youtube_flow(self, goal: str, context: dict) -> AgentResult:
        """
        YouTube search + play.
        Extracts the search query, calls web_youtube_search, then web_youtube_play_first.
        """
        # Extract query from goal
        import re
        # Try to strip "play/watch X on youtube" patterns
        query = goal
        for pat in [
            r"(?:play|watch|search for|search|find)\s+(.+?)(?:\s+on youtube)?$",
            r"youtube\s+(.+)$",
            r"(.+?)\s+on youtube$",
        ]:
            m = re.search(pat, goal, re.IGNORECASE)
            if m:
                query = m.group(1).strip()
                break

        # Direct two-step execution (no LLM needed for this flow)
        search_result = self._call_tool("web_youtube_search", {"query": query})
        if self._is_tool_error(search_result):
            return AgentResult(
                success=False,
                summary=f"I couldn't search YouTube for '{query}'. {search_result}",
                steps_taken=1,
                tool_calls=["web_youtube_search"]
            )

        play_result = self._call_tool("web_youtube_play_first", {})
        if self._is_tool_error(play_result):
            return AgentResult(
                success=False,
                summary=f"I found '{query}' on YouTube but couldn't play it. {play_result}",
                steps_taken=2,
                tool_calls=["web_youtube_search", "web_youtube_play_first"]
            )

        return AgentResult(
            success=True,
            summary=f"Playing '{query}' on YouTube.",
            steps_taken=2,
            tool_calls=["web_youtube_search", "web_youtube_play_first"]
        )

    def _on_step_complete(self, record: StepRecord) -> None:
        """After browser navigation, update active_url in context."""
        if record.tool in ("open_url", "open_url_and_wait", "browser_navigate") and record.success:
            # Extract URL from result if present
            if "http" in record.result:
                import re
                m = re.search(r'https?://\S+', record.result)
                if m:
                    self._active_context["active_url"] = m.group(0)
