"""
file_agent.py — Local file management for DEMASCAS.

Handles: finding files by name/type, opening them, listing directories,
reading PDFs, creating/deleting files.

Key behaviors:
- ALWAYS find_file before open_file (never guess a path)
- Multi-match → asks for clarification (delegated to C++ CLARIFYING state)
- Never opens a browser to find local files
- Never creates a file when asked to find/open one
"""

import re
import logging
from .base_agent import AgentBase, AgentResult, StepRecord

logger = logging.getLogger(__name__)

# Common folders to search when no folder is specified
DEFAULT_SEARCH_FOLDERS = ["~/Downloads", "~/Documents", "~/Desktop"]


class FileAgent(AgentBase):
    domain_name = "file"

    tool_names = [
        "find_file",
        "open_file",
        "list_files_in_folder",
        "create_file",
        "delete_file",
        "summarize_latest_pdf",
        # Vision for when we need to see what's in a file
        "get_active_window_tree",
        # Clipboard for file content
        "get_clipboard",
        "set_clipboard",
        # Press keyboard shortcut (e.g. cmd+option+l for Downloads)
        "press_keyboard_shortcut",
    ]

    @property
    def system_prompt(self) -> str:
        return """You are DEMASCAS's File Agent — a specialist in local macOS file management.

Your responsibilities:
- Finding files by name or partial name
- Opening files with their default application
- Listing directory contents
- Reading and summarizing PDFs
- Creating and deleting files

FILE RULES (follow these exactly):
1. ALWAYS call find_file FIRST before open_file. Never guess a file path.
2. Use tilde paths: ~/Downloads, ~/Documents, ~/Desktop. NEVER /Users/<name>/...
3. If find_file returns 0 matches: tell the user the file wasn't found. Do NOT create it. Do NOT open a browser.
4. If find_file returns 1 match: extract the path and call open_file with it.
5. If find_file returns multiple matches: use {"done": true, "say": "I found N files matching that. [list names]. Which one did you mean?"}
6. For PDFs: summarize_latest_pdf is more efficient than find_file + open_file when the user wants to READ content.
7. When folder is not specified, try ~/Downloads first, then ~/Documents, then ~/Desktop.
8. partial_name should be the most specific part of the filename — not generic words like "file", "pdf", "document".
9. extension should be the file extension WITHOUT the dot: "pdf", "docx", "xlsx", "pptx".
10. NEVER delete a file without explicit user confirmation in the goal."""

    def _extra_rules(self) -> str:
        return """11. For "open my latest PDF": use summarize_latest_pdf with folder=~/Downloads.
12. For "list files in X": use list_files_in_folder.
13. If asked to find a file without a folder hint, start with ~/Downloads."""

    def run(self, goal: str, context: dict) -> AgentResult:
        """
        Route to specialized sub-flows where possible,
        otherwise use the general step loop.
        """
        goal_lower = goal.lower()

        # Fast-path: "open [name].[ext]" — common, direct
        if self._is_direct_open(goal_lower):
            return self._direct_open_flow(goal, context)

        # Fast-path: list files
        if re.search(r"\b(list|show|what files|what's in)\b", goal_lower):
            return self._list_files_flow(goal, context)

        # General file task
        return self._execute(goal, context)

    # ── Specialized sub-flows ─────────────────────────────────────────────────

    def _is_direct_open(self, goal_lower: str) -> bool:
        """True if goal is a simple 'open X file' with an identifiable name."""
        return bool(re.search(
            r"\b(open|show|view|read|launch)\b.+\b(pdf|docx?|xlsx?|pptx?|txt|png|jpg|mp4|zip)\b",
            goal_lower
        ))

    def _direct_open_flow(self, goal: str, context: dict) -> AgentResult:
        """
        Optimized path for "open my X.pdf" type commands.
        Extracts partial_name and extension, runs find_file, then open_file.
        No LLM needed for the routing — just for name extraction on first call.
        """
        # Try regex extraction first (no LLM needed for clean commands)
        partial_name, extension, folder = self._extract_file_params(goal)

        if partial_name:
            result = self._call_tool("find_file", {
                "folder": folder,
                "partial_name": partial_name,
                "extension": extension,
            })

            if self._is_tool_error(result):
                # Try other folders
                for alt_folder in DEFAULT_SEARCH_FOLDERS:
                    if alt_folder == folder:
                        continue
                    result = self._call_tool("find_file", {
                        "folder": alt_folder,
                        "partial_name": partial_name,
                        "extension": extension,
                    })
                    if not self._is_tool_error(result):
                        break

            return self._handle_find_result(result, partial_name, extension, goal, context)

        # Fallback to LLM-guided loop
        return self._execute(goal, context)

    def _handle_find_result(self, result: str, partial_name: str,
                             extension: str, goal: str, context: dict) -> AgentResult:
        """Parse find_file result and take appropriate action."""
        import json
        try:
            data = json.loads(result) if result.startswith("{") else {}
        except Exception:
            data = {}

        found = data.get("found", False)
        count = data.get("count", 0)
        matches = data.get("matches", [])

        if not found or count == 0:
            return AgentResult(
                success=False,
                summary=f"I couldn't find any {extension.upper() if extension else 'file'} matching '{partial_name}'. "
                        f"Try checking your Downloads, Documents, or Desktop folders.",
                steps_taken=1,
                tool_calls=["find_file"]
            )

        if count == 1:
            path = matches[0]["path"]
            open_result = self._call_tool("open_file", {"file_path": path})
            if self._is_tool_error(open_result):
                return AgentResult(
                    success=False,
                    summary=f"I found the file but couldn't open it. {open_result}",
                    steps_taken=2,
                    tool_calls=["find_file", "open_file"]
                )
            name = matches[0].get("name", partial_name)
            return AgentResult(
                success=True,
                summary=f"Opening {name}.",
                steps_taken=2,
                tool_calls=["find_file", "open_file"]
            )

        # Multiple matches — report them and let C++ CLARIFYING state handle selection
        names = [m["name"] for m in matches[:5]]
        name_list = ", ".join(names)
        suffix = f" and {count - 5} more" if count > 5 else ""
        return AgentResult(
            success=True,
            summary=f"I found {count} files matching '{partial_name}': {name_list}{suffix}. Which one did you mean?",
            steps_taken=1,
            tool_calls=["find_file"],
            data={"pending_file_choices": matches[:8]}
        )

    def _list_files_flow(self, goal: str, context: dict) -> AgentResult:
        """List files in a directory."""
        # Extract folder from goal
        folder = "~/Downloads"  # default
        for known in ["downloads", "documents", "desktop"]:
            if known in goal.lower():
                folder = f"~/{known.capitalize()}"
                break

        result = self._call_tool("list_files_in_folder", {"folder_path": folder})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary=f"I couldn't list files in {folder}. {result}",
                steps_taken=1,
                tool_calls=["list_files_in_folder"]
            )

        # Parse result for a natural spoken summary
        lines = result.strip().split("\n")
        count = len([l for l in lines if l.strip() and not l.startswith("Folder:")])
        return AgentResult(
            success=True,
            summary=f"Found {count} items in {folder}. Check the Finder window for the full list.",
            steps_taken=1,
            tool_calls=["list_files_in_folder"]
        )

    def _extract_file_params(self, goal: str) -> tuple[str, str, str]:
        """
        Extract (partial_name, extension, folder) from a goal string.
        Returns ("", "", "~/Downloads") if extraction fails.
        """
        # Extension detection
        extension = ""
        ext_map = {
            "pdf": "pdf", "word": "docx", "doc": "docx", "docx": "docx",
            "excel": "xlsx", "xlsx": "xlsx", "xls": "xlsx",
            "powerpoint": "pptx", "pptx": "pptx", "slides": "pptx",
            "text": "txt", "txt": "txt",
            "image": "png", "photo": "jpg",
            "zip": "zip",
        }
        goal_lower = goal.lower()
        for keyword, ext in ext_map.items():
            if keyword in goal_lower:
                extension = ext
                break

        # Folder detection
        folder = "~/Downloads"
        if "document" in goal_lower:
            folder = "~/Documents"
        elif "desktop" in goal_lower:
            folder = "~/Desktop"

        # Name extraction — strip action words and common fillers
        strip_patterns = [
            r"\b(open|find|show|view|read|launch|my|the|a|an|please|can you)\b",
            r"\b(file|document|pdf|docx|xlsx|pptx|txt|folder)\b",
            r"\b(in|from|on|at|inside|within)\b",
            r"\b(downloads?|documents?|desktop)\b",
        ]
        name = goal_lower
        for pat in strip_patterns:
            name = re.sub(pat, " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\s+", " ", name).strip()

        # Reject generic names
        if not name or name in ("", " ", "latest", "recent", "new"):
            return ("", extension, folder)

        return (name, extension, folder)

    def _on_step_complete(self, record: StepRecord) -> None:
        """Track active file after open_file succeeds."""
        if record.tool == "open_file" and record.success:
            import re
            m = re.search(r'["\']?(/[^\s"\']+|~/[^\s"\']+)["\']?', record.result)
            if m:
                self._active_context["active_file"] = m.group(1)
