"""
base_agent.py — AgentBase class for DEMASCAS domain agents.

Design principles:
- One shared Qwen 3B (MLX) — agents take turns, never run in parallel
- Goal + step memory lives in the agent, NOT in the LLM context window
- Each LLM call gets a fresh, minimal context reconstructed from agent state
- Silent execution with a final summary spoken by the daemon
- Max 20 steps per task (vs 5 in the old ReAct loop)
- Hard error budget: 4 consecutive failures → abort with explanation
"""

import json
import time
import logging
import requests
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
import pytz

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────

MLX_TEXT_URL   = "http://127.0.0.1:8081/v1/chat/completions"
MLX_TEXT_MODEL = "mlx-community/Qwen2.5-3B-Instruct-4bit"
TOOL_SERVER    = "http://127.0.0.1:5001"

MAX_STEPS          = 20     # hard cap per task (vs 5 in old ReAct)
MAX_ERRORS         = 4      # consecutive tool errors before abort
LLM_TIMEOUT        = 30     # seconds per LLM call
TOOL_TIMEOUT       = 30     # seconds per tool execution
TOOL_CTX           = 2048   # context window tokens
TOOL_PREDICT       = 256    # max tokens per LLM response
LLM_TEMPERATURE    = 0.1    # low = deterministic tool selection

IST = pytz.timezone("Asia/Kolkata")


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class StepRecord:
    """One completed step in the agent's execution history."""
    step_num:   int
    tool:       str
    args:       dict
    result:     str
    success:    bool
    timestamp:  float = field(default_factory=time.time)

    def compact(self) -> str:
        """Single-line summary for LLM context injection."""
        status = "OK" if self.success else "FAIL"
        result_preview = self.result[:120].replace("\n", " ") if self.result else ""
        return f"[{self.step_num}] {self.tool}({json.dumps(self.args)}) → {status}: {result_preview}"


@dataclass
class AgentResult:
    """Return value from agent.run() back to the Flask endpoint."""
    success:     bool
    summary:     str           # spoken aloud by TTS
    steps_taken: int
    tool_calls:  list[str]
    error:       Optional[str] = None
    data:        Optional[dict] = None   # optional structured payload


# ── AgentBase ────────────────────────────────────────────────────────────────

class AgentBase(ABC):
    """
    Base class for all DEMASCAS domain agents.

    Subclasses must implement:
        domain_name:    str          (e.g. "browser", "file")
        tool_names:     list[str]    tools this agent is allowed to use
        system_prompt:  str          domain-specific LLM instructions
        run(goal, context) → AgentResult

    Subclasses may override:
        _build_context_block()       inject extra info into each LLM call
        _on_step_complete()          hook called after each tool execution
    """

    domain_name:   str       = "base"
    tool_names:    list[str] = []

    def __init__(self):
        self._goal:         str              = ""
        self._steps:        list[StepRecord] = []
        self._step_count:   int              = 0
        self._error_streak: int              = 0
        self._start_time:   float            = 0.0
        self._tool_schemas: Optional[list]   = None  # cached from tool server
        self._active_context: dict           = {}    # from ACTIVE_CONTEXT on server

    # ── Public API ────────────────────────────────────────────────────────────

    @abstractmethod
    def run(self, goal: str, context: dict) -> AgentResult:
        """
        Execute a goal. Called by the dispatcher.

        Args:
            goal:    The user's command (normalized transcription)
            context: ACTIVE_CONTEXT snapshot from tool_server at dispatch time

        Returns:
            AgentResult with a summary string ready for TTS
        """
        ...

    # ── Core step loop (shared by all agents) ────────────────────────────────

    def _execute(self, goal: str, context: dict) -> AgentResult:
        """
        Main ReAct loop. Subclasses call this from run().
        Runs up to MAX_STEPS tool calls, accumulating StepRecords.
        Returns AgentResult when done=true or error budget exhausted.
        """
        self._goal          = goal
        self._steps         = []
        self._step_count    = 0
        self._error_streak  = 0
        self._start_time    = time.time()
        self._active_context = context
        tool_calls_made     = []

        # Fetch tool schemas once per task
        self._tool_schemas = self._fetch_tool_schemas()
        if not self._tool_schemas:
            return AgentResult(
                success=False,
                summary="I couldn't reach the tool server. Please check that it's running.",
                steps_taken=0,
                tool_calls=[],
                error="tool_server_unavailable"
            )

        logger.info(f"[{self.domain_name}] Starting task: {goal[:80]}")

        for step_num in range(1, MAX_STEPS + 1):
            self._step_count = step_num

            # Build compact history for this LLM call (last 6 steps max)
            history_block = self._build_history_block()
            context_block = self._build_context_block()

            # LLM call
            action = self._call_llm(goal, history_block, context_block)
            if action is None:
                self._error_streak += 1
                logger.warning(f"[{self.domain_name}] LLM parse failure at step {step_num}")
                if self._error_streak >= MAX_ERRORS:
                    return self._abort("LLM stopped producing valid actions.")
                continue

            # Terminal action
            if action.get("done"):
                summary = action.get("say", "Done.")
                logger.info(f"[{self.domain_name}] Task complete in {step_num} steps.")
                return AgentResult(
                    success=True,
                    summary=summary,
                    steps_taken=step_num,
                    tool_calls=tool_calls_made
                )

            # Tool action
            tool_name = action.get("tool", "")
            tool_args = action.get("args", {})

            if not tool_name:
                self._error_streak += 1
                continue

            # Guard: only allow tools in this agent's scope
            if tool_name not in self.tool_names:
                logger.warning(f"[{self.domain_name}] Blocked out-of-scope tool: {tool_name}")
                self._record_step(step_num, tool_name, tool_args,
                                  f"Tool '{tool_name}' is not available to the {self.domain_name} agent.",
                                  success=False)
                self._error_streak += 1
                if self._error_streak >= MAX_ERRORS:
                    return self._abort(f"Repeated attempts to use unavailable tools.")
                continue

            # Dedup guard: don't repeat exact same call
            if self._is_duplicate(tool_name, tool_args):
                logger.warning(f"[{self.domain_name}] Duplicate tool call blocked: {tool_name}")
                self._record_step(step_num, tool_name, tool_args,
                                  "Duplicate call — already executed this step.",
                                  success=False)
                self._error_streak += 1
                if self._error_streak >= MAX_ERRORS:
                    return self._abort("Agent stuck in a loop.")
                continue

            # Execute tool
            result = self._call_tool(tool_name, tool_args)
            is_error = self._is_tool_error(result)
            tool_calls_made.append(tool_name)

            record = self._record_step(step_num, tool_name, tool_args, result, success=not is_error)
            self._on_step_complete(record)

            if is_error:
                self._error_streak += 1
                logger.warning(f"[{self.domain_name}] Tool error at step {step_num}: {result[:80]}")
                if self._error_streak >= MAX_ERRORS:
                    return self._abort(f"Too many tool failures. Last error: {result[:120]}")
            else:
                self._error_streak = 0  # reset on success

        # Exceeded MAX_STEPS
        return self._abort(f"Task exceeded {MAX_STEPS} steps without completion.")

    # ── LLM interface ─────────────────────────────────────────────────────────

    def _call_llm(self, goal: str, history_block: str, context_block: str) -> Optional[dict]:
        """
        Single LLM call. Returns parsed action dict or None on failure.
        Action formats:
            {"tool": "tool_name", "args": {...}}
            {"done": true, "say": "spoken summary"}
        """
        now = datetime.now(IST)
        time_str = now.strftime("%I:%M %p IST")
        date_str = now.strftime("%A, %B %d %Y")

        tool_schema_block = self._format_tool_schemas()

        system = f"""{self.system_prompt}

Current time: {time_str} | Date: {date_str}

AVAILABLE TOOLS:
{tool_schema_block}

EXECUTION RULES:
1. Respond ONLY with JSON. No prose, no markdown, no explanation.
2. To call a tool: {{"tool": "tool_name", "args": {{...}}}}
3. When the task is complete: {{"done": true, "say": "brief spoken summary"}}
4. ONE action per response. Never call two tools at once.
5. NEVER invent tool names. Use only the tools listed above.
6. Use ~/Downloads, ~/Documents, ~/Desktop — NEVER /Users/<name>/...
7. For file operations: always find_file FIRST, then open_file with the result.
{self._extra_rules()}

CURRENT STATE:
{context_block}

EXECUTION HISTORY (last steps):
{history_block if history_block else "No steps taken yet."}"""

        messages = [
            {"role": "system", "content": system},
            {"role": "user",   "content": f"Complete this task: {goal}"}
        ]

        try:
            resp = requests.post(
                MLX_TEXT_URL,
                json={
                    "model":       MLX_TEXT_MODEL,
                    "messages":    messages,
                    "max_tokens":  TOOL_PREDICT,
                    "temperature": LLM_TEMPERATURE,
                    "stream":      False,
                },
                timeout=LLM_TIMEOUT
            )
            resp.raise_for_status()
            raw = resp.json()["choices"][0]["message"]["content"].strip()
            return self._parse_action(raw)
        except Exception as e:
            logger.error(f"[{self.domain_name}] LLM call failed: {e}")
            return None

    def _parse_action(self, raw: str) -> Optional[dict]:
        """Extract the first valid JSON action dict from LLM output."""
        # Strip markdown fences
        raw = raw.replace("```json", "").replace("```", "").strip()

        # Try direct parse
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict) and ("tool" in obj or "done" in obj):
                return obj
        except json.JSONDecodeError:
            pass

        # Scan for {...} blocks
        depth = 0
        start = -1
        for i, ch in enumerate(raw):
            if ch == "{":
                if depth == 0:
                    start = i
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0 and start != -1:
                    candidate = raw[start:i+1]
                    try:
                        obj = json.loads(candidate)
                        if isinstance(obj, dict) and ("tool" in obj or "done" in obj):
                            return obj
                    except json.JSONDecodeError:
                        continue
        return None

    # ── Tool execution ────────────────────────────────────────────────────────

    def _call_tool(self, name: str, args: dict) -> str:
        """Execute a tool via the tool server and return result string."""
        try:
            resp = requests.post(
                f"{TOOL_SERVER}/tool",
                json={"name": name, "arguments": args},
                timeout=TOOL_TIMEOUT
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("result", str(data))
        except requests.Timeout:
            return f"Timeout: {name} took longer than {TOOL_TIMEOUT}s"
        except Exception as e:
            return f"Error: {name} failed — {str(e)}"

    def _fetch_tool_schemas(self) -> Optional[list]:
        """Fetch filtered tool schemas relevant to this agent's domain."""
        try:
            resp = requests.post(
                f"{TOOL_SERVER}/tools_for_query",
                json={"query": self.domain_name, "max_tools": len(self.tool_names) + 4},
                timeout=10
            )
            resp.raise_for_status()
            all_schemas = resp.json()
            # Filter to only this agent's allowed tools
            return [
                s for s in all_schemas
                if s.get("function", {}).get("name", "") in self.tool_names
            ]
        except Exception as e:
            logger.error(f"[{self.domain_name}] Failed to fetch tool schemas: {e}")
            return []

    def _format_tool_schemas(self) -> str:
        """Format tool schemas as compact text for the system prompt."""
        if not self._tool_schemas:
            return "(no tools available)"
        lines = []
        for schema in self._tool_schemas:
            fn = schema.get("function", {})
            name = fn.get("name", "")
            desc = fn.get("description", "").split("\n")[0][:100]
            params = fn.get("parameters", {}).get("properties", {})
            param_str = ", ".join(
                f"{k}: {v.get('type','any')}"
                for k, v in params.items()
            )
            lines.append(f"- {name}({param_str}) — {desc}")
        return "\n".join(lines)

    # ── State helpers ─────────────────────────────────────────────────────────

    def _record_step(self, step_num: int, tool: str, args: dict,
                     result: str, success: bool) -> StepRecord:
        record = StepRecord(step_num, tool, args, result, success)
        self._steps.append(record)
        return record

    def _build_history_block(self) -> str:
        """Last 6 steps as compact single-line summaries."""
        recent = self._steps[-6:]
        return "\n".join(s.compact() for s in recent)

    def _build_context_block(self) -> str:
        """Active context from tool server — app, URL, last result, etc."""
        ctx = self._active_context
        lines = []
        if ctx.get("active_app"):
            lines.append(f"Active app: {ctx['active_app']}")
        if ctx.get("active_url"):
            lines.append(f"Current URL: {ctx['active_url']}")
        if ctx.get("active_file"):
            lines.append(f"Active file: {ctx['active_file']}")
        if ctx.get("last_tool_result"):
            preview = str(ctx["last_tool_result"])[:150].replace("\n", " ")
            lines.append(f"Last result: {preview}")
        return "\n".join(lines) if lines else "No prior context."

    def _is_duplicate(self, tool: str, args: dict) -> bool:
        """True if the last 2 steps used the exact same tool+args."""
        recent = self._steps[-2:]
        for s in recent:
            if s.tool == tool and s.args == args:
                return True
        return False

    def _is_tool_error(self, result: str) -> bool:
        """Detect tool failure markers."""
        if not result:
            return True
        lower = result.lower()
        error_prefixes = ("error:", "failed:", "timeout:", "[-]", "exception", "traceback")
        return any(lower.startswith(p) for p in error_prefixes)

    def _abort(self, reason: str) -> AgentResult:
        """Build a graceful abort result."""
        steps = len(self._steps)
        logger.error(f"[{self.domain_name}] Aborting after {steps} steps: {reason}")
        return AgentResult(
            success=False,
            summary=f"I wasn't able to complete that. {reason}",
            steps_taken=steps,
            tool_calls=[s.tool for s in self._steps],
            error=reason
        )

    # ── Subclass hooks ────────────────────────────────────────────────────────

    def _on_step_complete(self, record: StepRecord) -> None:
        """Called after each tool execution. Override for domain-specific side effects."""
        pass

    def _extra_rules(self) -> str:
        """Additional rules injected into system prompt. Override per domain."""
        return ""

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        """Domain-specific system prompt. Must be defined by each subclass."""
        ...
