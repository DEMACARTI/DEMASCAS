/*
 * cpp_agent_patch.md
 *
 * Two changes needed in the C++ daemon to wire up PATH 3.5 (Agent routing).
 * Both changes are surgical — no restructuring of existing paths.
 *
 * ════════════════════════════════════════════════════════════════════════════
 * CHANGE 1: tool_bridge.cpp / tool_bridge.hpp — add execute_agent()
 * ════════════════════════════════════════════════════════════════════════════
 *
 * In tool_bridge.hpp, add to the ToolBridge class:
 *
 *     struct AgentResult {
 *         bool        success;
 *         std::string summary;      // spoken by TTS
 *         int         steps_taken;
 *         std::string error;
 *         std::string raw_json;     // full response for logging
 *     };
 *
 *     AgentResult execute_agent(const std::string& command,
 *                               const std::string& context_json = "{}");
 *
 * ─────────────────────────────────────────────────────────────────────────
 * In tool_bridge.cpp, add the implementation:
 * ─────────────────────────────────────────────────────────────────────────

ToolBridge::AgentResult ToolBridge::execute_agent(
    const std::string& command,
    const std::string& context_json)
{
    AgentResult out;
    out.success     = false;
    out.steps_taken = 0;

    // Build request body
    nlohmann::json body;
    body["command"] = command;
    try {
        body["context"] = nlohmann::json::parse(context_json);
    } catch (...) {
        body["context"] = nlohmann::json::object();
    }

    std::string payload = body.dump();
    std::string response_str;

    // POST to /agent (30s timeout — agents can run many steps)
    CURL* curl = curl_easy_init();
    if (!curl) {
        out.error = "curl init failed";
        return out;
    }

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    curl_easy_setopt(curl, CURLOPT_URL, (TOOL_SERVER_BASE + "/agent").c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);  // agents can take up to 60s

    // Write callback (reuse the same lambda pattern as execute())
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,
        +[](char* ptr, size_t size, size_t nmemb, void* userdata) -> size_t {
            auto* s = static_cast<std::string*>(userdata);
            s->append(ptr, size * nmemb);
            return size * nmemb;
        });
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_str);

    CURLcode res = curl_easy_perform(curl);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        out.error = std::string("curl error: ") + curl_easy_strerror(res);
        return out;
    }

    // Parse response
    try {
        auto j          = nlohmann::json::parse(response_str);
        out.success     = j.value("success", false);
        out.summary     = j.value("summary", "");
        out.steps_taken = j.value("steps_taken", 0);
        out.error       = j.value("error", "");
        out.raw_json    = response_str;
    } catch (const std::exception& e) {
        out.error = std::string("JSON parse error: ") + e.what();
    }

    return out;
}

 *
 * ════════════════════════════════════════════════════════════════════════════
 * CHANGE 2: main.cpp — add PATH 3.5 in the PROCESSING state
 * ════════════════════════════════════════════════════════════════════════════
 *
 * In shortcut_map.hpp, add this function (after is_multi_step_command):
 *

inline bool is_agent_command(const std::string& cmd) {
    // Agent path: complex single-domain tasks that don't need multi-step planning
    // but benefit from domain-specialized context (>5 steps, memory, specialization)
    static const std::vector<std::string> AGENT_TRIGGERS = {
        // Browser domain
        "compose email", "write email", "draft email",
        "reply to", "smart reply", "respond to that",
        "open gmail", "check email", "read email",
        "browse to", "navigate to", "go to website",
        "youtube", "watch video", "play video",
        "search the web", "look up online",
        // File domain
        "summarize the pdf", "read the pdf",
        "find all", "list all files",
        // Research domain
        "research", "look up", "tell me about",
        "weather in", "news about", "latest on",
        "find information", "find out",
        // Comms domain
        "extract contact", "who emailed",
    };

    std::string lower = cmd;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);

    for (const auto& trigger : AGENT_TRIGGERS) {
        if (lower.find(trigger) != std::string::npos) {
            return true;
        }
    }
    return false;
}

 *
 * ─────────────────────────────────────────────────────────────────────────
 * In main.cpp PROCESSING state, add PATH 3.5 BEFORE PATH 3 (the ReAct loop):
 * ─────────────────────────────────────────────────────────────────────────
 *
 * Find this block in main.cpp (the PATH 3 / tool ReAct section):
 *
 *     // PATH 3: Tool ReAct (default fallback)
 *     else {
 *         chat_with_tools_streaming(...);
 *     }
 *
 * Change it to:
 *

    // PATH 3.5: Domain Agent (specialized, multi-step, memory-aware)
    else if (is_agent_command(normalized_command)) {

        // Snapshot ACTIVE_CONTEXT for the agent
        std::string context_json = "{}";
        try {
            auto ctx = tool_bridge.fetch_active_context();  // GET /session
            if (!ctx.empty()) context_json = ctx;
        } catch (...) {}

        auto agent_result = tool_bridge.execute_agent(normalized_command, context_json);

        if (!agent_result.summary.empty()) {
            // Stream the summary to TTS sentence by sentence
            std::string summary = agent_result.summary;
            // Split on ". " for sentence-by-sentence TTS
            std::string buf;
            for (char c : summary) {
                buf += c;
                if ((c == '.' || c == '!' || c == '?') && buf.size() > 10) {
                    on_sentence(buf);
                    buf.clear();
                }
            }
            if (!buf.empty() && !buf.empty()) on_sentence(buf);
        } else if (!agent_result.error.empty()) {
            on_sentence("I ran into an issue: " + agent_result.error.substr(0, 80));
        }

        // Log interaction
        std::string tools_str;
        // (tools are in agent_result.raw_json if needed for logging)
        tool_bridge.log_interaction(
            normalized_command,
            "PATH_3.5_AGENT",
            tools_str,
            agent_result.summary,
            agent_result.success
        );
    }

    // PATH 3: Tool ReAct (default fallback for everything else)
    else {
        chat_with_tools_streaming(...);
    }

 *
 * ─────────────────────────────────────────────────────────────────────────
 * CHANGE 3: tool_bridge — add fetch_active_context() (small addition)
 * ─────────────────────────────────────────────────────────────────────────
 *
 * In tool_bridge.hpp, add:
 *     std::string fetch_active_context();
 *
 * In tool_bridge.cpp, add:
 *

std::string ToolBridge::fetch_active_context() {
    // GET /session → returns ACTIVE_CONTEXT as JSON string
    std::string response;
    CURL* curl = curl_easy_init();
    if (!curl) return "{}";

    curl_easy_setopt(curl, CURLOPT_URL, (TOOL_SERVER_BASE + "/session").c_str());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,
        +[](char* ptr, size_t size, size_t nmemb, void* userdata) -> size_t {
            auto* s = static_cast<std::string*>(userdata);
            s->append(ptr, size * nmemb);
            return size * nmemb;
        });
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    return response.empty() ? "{}" : response;
}

 *
 * ════════════════════════════════════════════════════════════════════════════
 * SUMMARY OF ALL CHANGES
 * ════════════════════════════════════════════════════════════════════════════
 *
 * Files changed:
 *   server/tool_server.py    — add 2 imports + 2 new endpoints (/agent, /agent/route)
 *   server/agents/           — NEW directory (all files in this PR)
 *   daemon/src/shortcut_map.hpp  — add is_agent_command() function
 *   daemon/src/tool_bridge.hpp   — add AgentResult struct + 2 method declarations
 *   daemon/src/tool_bridge.cpp   — add execute_agent() + fetch_active_context()
 *   daemon/src/main.cpp          — add PATH 3.5 block before PATH 3
 *
 * Files NOT changed:
 *   Everything else — all existing paths (1, 1.5, 1.6, 1.7, 1.8, 2, 2.5, 4) untouched.
 *   The ReAct loop (PATH 3) remains as the final fallback.
 */
