"""
dispatcher.py — Routes incoming commands to the appropriate domain agent.

Routing priority:
1. Keyword match against DOMAIN_KEYWORDS (fast, no LLM)
2. Pattern score — pick highest-scoring domain
3. Fallback → SystemAgent (most general-purpose)

The dispatcher also decides WHETHER to use an agent at all.
Simple/fast commands should still go through the existing C++ paths.
"""

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ── Domain keyword maps ───────────────────────────────────────────────────────
# Each domain maps to a list of trigger keywords/phrases.
# Longer phrases score higher (more specific match).

DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "browser": [
        "open gmail", "check email", "compose email", "reply to email",
        "send email", "read email", "gmail", "mail",
        "browse", "navigate to", "go to website", "open website",
        "search the web", "look up online", "google it",
        "youtube", "watch video", "play video",
        "download from", "web page", "webpage",
        "brave", "browser", "tab", "website",
        "shop for", "buy online", "amazon", "order",
        "log in", "sign in", "fill form",
        "click on the", "click the button",
    ],
    "file": [
        "open my", "open the file", "open this file",
        "find the", "find my", "find file",
        "pdf", "document", "docx", "spreadsheet", "excel",
        "pptx", "presentation", "slides",
        "download folder", "documents folder", "desktop",
        "show me the file", "list files", "what files",
        "create a file", "make a new file", "save as",
        "delete the file", "move the file", "rename",
        "read the pdf", "summarize the pdf",
        "latest pdf", "most recent file",
    ],
    "research": [
        "research", "look up", "find information about",
        "tell me about", "what is", "who is", "summarize",
        "explain", "define", "learn about",
        "news about", "latest on", "what happened",
        "weather in", "weather today",
        "compare", "difference between",
        "find out", "dig into", "investigate",
    ],
    "comms": [
        "compose a message", "draft a message", "write an email",
        "reply to", "respond to",
        "send a message to", "message",
        "smart reply", "reply with",
        "extract contact", "find contact info",
        "who emailed", "what did they say",
        "schedule a meeting", "set up a call",
    ],
    "system": [
        "open app", "launch", "quit", "close app",
        "switch to", "activate",
        "take a screenshot", "screenshot",
        "volume up", "volume down", "mute",
        "brightness", "sleep", "lock",
        "copy", "paste", "undo", "redo",
        "new window", "new tab", "close window",
        "type this", "click on", "scroll down", "scroll up",
        "press", "keyboard shortcut",
        "what's on screen", "what do you see",
        "list running apps", "running apps",
    ],
}

# Domains ordered by specificity — more specific domains checked first
_DOMAIN_PRIORITY = ["comms", "browser", "file", "research", "system"]


# ── Dispatcher ────────────────────────────────────────────────────────────────

class AgentDispatcher:
    """
    Routes a command string to the correct domain agent class name.

    Usage:
        dispatcher = AgentDispatcher()
        domain = dispatcher.route("find my SIH 2025 PDF and open it")
        # → "file"
    """

    def __init__(self):
        # Pre-compile patterns: longer phrases first (more specific → higher score)
        self._patterns: dict[str, list[tuple[re.Pattern, int]]] = {}
        for domain, keywords in DOMAIN_KEYWORDS.items():
            sorted_kws = sorted(keywords, key=len, reverse=True)
            compiled = []
            for kw in sorted_kws:
                score = len(kw.split())  # word count = score
                pattern = re.compile(r'\b' + re.escape(kw) + r'\b', re.IGNORECASE)
                compiled.append((pattern, score))
            self._patterns[domain] = compiled

    def route(self, command: str) -> str:
        """
        Returns the domain name string for the best-matching agent.
        Always returns a valid domain (falls back to 'system').
        """
        scores: dict[str, int] = {d: 0 for d in DOMAIN_KEYWORDS}

        for domain in _DOMAIN_PRIORITY:
            for pattern, score in self._patterns[domain]:
                if pattern.search(command):
                    scores[domain] += score

        best_domain = max(scores, key=lambda d: scores[d])
        best_score  = scores[best_domain]

        if best_score == 0:
            logger.debug(f"[dispatcher] No keyword match for '{command[:60]}' → fallback: system")
            return "system"

        logger.debug(f"[dispatcher] '{command[:60]}' → {best_domain} (score={best_score})")
        return best_domain

    def route_with_scores(self, command: str) -> dict[str, int]:
        """Debug helper — returns scores for all domains."""
        scores: dict[str, int] = {d: 0 for d in DOMAIN_KEYWORDS}
        for domain in _DOMAIN_PRIORITY:
            for pattern, score in self._patterns[domain]:
                if pattern.search(command):
                    scores[domain] += score
        return scores

    def should_use_agent(self, command: str) -> bool:
        """
        Returns True if this command is complex enough to warrant agent routing
        rather than the existing C++ shortcut/fast-path handlers.

        Agents are appropriate for:
        - Multi-step workflows
        - Domain-specific tasks needing memory across steps
        - Research, composition, autonomous browsing

        NOT appropriate for:
        - Simple questions (handled by PATH 2)
        - Keyboard shortcuts (PATH 1)
        - Single app open/close (PATH 1.6/1.7)
        """
        cmd = command.lower().strip()

        # Single-step app commands → keep in C++ paths
        single_step_patterns = [
            r"^(open|launch|start)\s+\w+$",
            r"^(quit|close|exit)\s+\w+$",
            r"^(copy|paste|undo|redo|save)$",
            r"^(mute|unmute|volume up|volume down)$",
        ]
        for pat in single_step_patterns:
            if re.match(pat, cmd):
                return False

        # Agents are warranted for multi-step indicators
        multi_step_signals = [
            r"\b(then|and then|after that|next|also|finally)\b",
            r"\b(find|search|look up|research|summarize)\b",
            r"\b(compose|draft|write|reply|respond)\b",
            r"\b(open my|open the file|my pdf|my document)\b",
            r"\b(browse|navigate|go to|open website)\b",
            r"\b(youtube|watch|play video)\b",
            r"\b(email|gmail|mail)\b",
        ]
        for pat in multi_step_signals:
            if re.search(pat, cmd):
                return True

        return False


# ── Module-level singleton ────────────────────────────────────────────────────

_dispatcher_instance: Optional[AgentDispatcher] = None

def get_dispatcher() -> AgentDispatcher:
    global _dispatcher_instance
    if _dispatcher_instance is None:
        _dispatcher_instance = AgentDispatcher()
    return _dispatcher_instance


def route_command(command: str) -> str:
    """Convenience function — returns domain name for a command."""
    return get_dispatcher().route(command)


def should_use_agent(command: str) -> bool:
    """Convenience function — True if command warrants agent routing."""
    return get_dispatcher().should_use_agent(command)
