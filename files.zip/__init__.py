"""
agents/__init__.py — DEMASCAS agent system.

Public API:
    run_agent(command, context) → AgentResult
    route_command(command) → str (domain name)
    should_use_agent(command) → bool
"""

from .base_agent    import AgentBase, AgentResult, StepRecord
from .dispatcher    import AgentDispatcher, route_command, should_use_agent, get_dispatcher
from .browser_agent import BrowserAgent
from .file_agent    import FileAgent
from .system_agent  import SystemAgent
from .research_agent import ResearchAgent
from .comms_agent   import CommsAgent

import logging
logger = logging.getLogger(__name__)

# ── Agent registry ────────────────────────────────────────────────────────────

_AGENT_CLASSES = {
    "browser":  BrowserAgent,
    "file":     FileAgent,
    "system":   SystemAgent,
    "research": ResearchAgent,
    "comms":    CommsAgent,
}

# Agent instances — created once and reused (stateless between tasks after run())
_AGENT_INSTANCES: dict[str, AgentBase] = {}


def _get_agent(domain: str) -> AgentBase:
    """Return cached agent instance for a domain, creating it if needed."""
    if domain not in _AGENT_INSTANCES:
        cls = _AGENT_CLASSES.get(domain, SystemAgent)
        _AGENT_INSTANCES[domain] = cls()
        logger.info(f"[agents] Initialized {domain} agent ({cls.__name__})")
    return _AGENT_INSTANCES[domain]


def run_agent(command: str, context: dict) -> AgentResult:
    """
    Main entry point — route command to the appropriate agent and execute.

    Args:
        command: Normalized transcription from the C++ daemon
        context: ACTIVE_CONTEXT snapshot from tool_server

    Returns:
        AgentResult with .summary (spoken by TTS) and .success
    """
    domain = route_command(command)
    agent  = _get_agent(domain)

    logger.info(f"[agents] Dispatching to {domain} agent: '{command[:60]}'")

    try:
        result = agent.run(command, context)
        logger.info(
            f"[agents] {domain} agent done — success={result.success}, "
            f"steps={result.steps_taken}, tools={result.tool_calls}"
        )
        return result
    except Exception as e:
        logger.exception(f"[agents] Unhandled exception in {domain} agent: {e}")
        return AgentResult(
            success=False,
            summary="Something went wrong while executing that task. Please try again.",
            steps_taken=0,
            tool_calls=[],
            error=str(e)
        )


__all__ = [
    "AgentBase", "AgentResult", "StepRecord",
    "AgentDispatcher", "route_command", "should_use_agent", "get_dispatcher",
    "BrowserAgent", "FileAgent", "SystemAgent", "ResearchAgent", "CommsAgent",
    "run_agent",
]
