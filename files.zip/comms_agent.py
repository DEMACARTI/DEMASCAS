"""
comms_agent.py — Communication specialist for DEMASCAS.

Handles: email composition with tone matching, smart replies,
contact extraction, message drafting.

Key behaviors:
- Reads screen to extract context before composing
- Never auto-sends — always creates a draft
- Tone matching: reads existing email and mirrors formality level
- Asks for email address if not provided
- Works both in native Mail app and Gmail in Brave
"""

import re
import logging
from .base_agent import AgentBase, AgentResult, StepRecord

logger = logging.getLogger(__name__)


class CommsAgent(AgentBase):
    domain_name = "comms"

    tool_names = [
        # Email reading
        "read_current_email",
        "gmail_read_email",
        # Email composing
        "compose_email",
        "gmail_compose_draft",
        # Smart actions
        "smart_reply",
        "extract_contact",
        "web_research_and_report",
        # Screen context (to understand current email)
        "get_active_window_tree",
        "vision_execute",
        # Clipboard (for pasting email content)
        "get_clipboard",
        "set_clipboard",
        # URL navigation (to open Gmail)
        "open_url_and_wait",
    ]

    @property
    def system_prompt(self) -> str:
        return """You are DEMASCAS's Communications Agent — a specialist in email and messaging.

Your responsibilities:
- Composing new emails with appropriate tone
- Smart replies to existing emails
- Extracting contact information from screen
- Drafting messages based on user intent

COMMS RULES:
1. NEVER send any email automatically. Always compose a draft only.
2. If the user says "compose email to [name]" but no email address is given:
   - First try extract_contact to find their email from screen or memory
   - If not found, end with {"done": true, "say": "What is [name]'s email address?"}
3. For "reply to that email" or "smart reply": first call read_current_email to get context.
4. If in Gmail (active_url contains mail.google.com): use gmail_compose_draft.
5. If in native Mail app: use compose_email.
6. compose_email returns a draft JSON for user review — it does NOT send.
7. gmail_compose_draft opens the Gmail compose window — it does NOT send.
8. Match the tone of the original email when replying:
   - Formal email → formal reply
   - Casual email → casual reply
9. Extract key points from the user's spoken command for the email body.
10. Always confirm: {"done": true, "say": "I've drafted an email to [recipient] with subject '[subject]'. Ready to review."}"""

    def _extra_rules(self) -> str:
        return """11. Don't ask for information you can infer — if user says "reply professionally", you know the tone.
12. If user says "send it", that means they confirmed a pending draft — still use compose_email/gmail_compose_draft.
13. For "who emailed me" or "check emails": read_current_email gives a structured summary."""

    def run(self, goal: str, context: dict) -> AgentResult:
        goal_lower = goal.lower()

        # Fast-path: smart reply (read existing email → generate reply)
        if re.search(r"\b(reply|respond)\b.*\b(email|message|that|it)\b", goal_lower):
            return self._smart_reply_flow(goal, context)

        # Fast-path: check/read emails
        if re.search(r"\b(read|check|show|what|any)\b.*\b(email|emails|mail|inbox)\b", goal_lower):
            return self._read_email_flow(goal, context)

        # Fast-path: extract contact
        if re.search(r"\b(contact|email address|phone number|find)\b.*\b(info|information|for|of)\b", goal_lower):
            return self._extract_contact_flow(goal, context)

        # General composition — use full step loop
        return self._execute(goal, context)

    # ── Specialized sub-flows ─────────────────────────────────────────────────

    def _smart_reply_flow(self, goal: str, context: dict) -> AgentResult:
        """
        Read current email context from screen, then generate a smart reply draft.
        """
        active_url = context.get("active_url", "")

        # Read the email first
        if "mail.google.com" in active_url:
            email_content = self._call_tool("gmail_read_email", {})
        else:
            email_content = self._call_tool("read_current_email", {})

        if self._is_tool_error(email_content) or not email_content.strip():
            return AgentResult(
                success=False,
                summary="I couldn't read the current email. Please make sure an email is open.",
                steps_taken=1,
                tool_calls=["read_current_email"]
            )

        # Inject email content into context for the step loop
        self._active_context = {
            **context,
            "last_tool_result": email_content,
            "task_hint": f"Original email content: {email_content[:300]}. Goal: {goal}",
        }

        # Use smart_reply for context-aware drafting
        reply_result = self._call_tool("smart_reply", {"context": email_content})
        if self._is_tool_error(reply_result):
            # Fallback to full step loop
            return self._execute(goal, self._active_context)

        return AgentResult(
            success=True,
            summary="I've drafted a reply based on the email. Check the compose window.",
            steps_taken=2,
            tool_calls=["read_current_email", "smart_reply"]
        )

    def _read_email_flow(self, goal: str, context: dict) -> AgentResult:
        """Read and summarize current or recent emails."""
        active_url = context.get("active_url", "")

        if "mail.google.com" in active_url:
            result = self._call_tool("gmail_read_email", {})
        else:
            result = self._call_tool("read_current_email", {})

        if self._is_tool_error(result) or not result.strip():
            return AgentResult(
                success=False,
                summary="I couldn't find any open email to read. Please open an email first.",
                steps_taken=1,
                tool_calls=["read_current_email"]
            )

        # Parse email fields for spoken summary
        from_match    = re.search(r"from[:\s]+([^\n]+)", result, re.IGNORECASE)
        subject_match = re.search(r"subject[:\s]+([^\n]+)", result, re.IGNORECASE)

        from_str    = from_match.group(1).strip()[:50]    if from_match    else "unknown sender"
        subject_str = subject_match.group(1).strip()[:60] if subject_match else "no subject"

        return AgentResult(
            success=True,
            summary=f"Email from {from_str}, subject: {subject_str}.",
            steps_taken=1,
            tool_calls=["read_current_email"]
        )

    def _extract_contact_flow(self, goal: str, context: dict) -> AgentResult:
        """Extract contact info from screen or context."""
        # Extract name from goal
        name = ""
        m = re.search(
            r"(?:contact|info|information|email address|phone)\s+(?:for|of|about)\s+([A-Za-z\s]+?)(?:\s*$|\?)",
            goal, re.IGNORECASE
        )
        if m:
            name = m.group(1).strip()

        result = self._call_tool("extract_contact", {"name": name} if name else {})
        if self._is_tool_error(result) or not result.strip():
            return AgentResult(
                success=False,
                summary=f"I couldn't find contact info{' for ' + name if name else ''}.",
                steps_taken=1,
                tool_calls=["extract_contact"]
            )

        return AgentResult(
            success=True,
            summary=result.strip()[:200],
            steps_taken=1,
            tool_calls=["extract_contact"]
        )

    def _on_step_complete(self, record: StepRecord) -> None:
        """Track email context after reads."""
        if record.tool in ("read_current_email", "gmail_read_email") and record.success:
            self._active_context["last_tool_result"] = record.result[:300]
