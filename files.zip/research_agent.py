"""
research_agent.py — Web research and information synthesis for DEMASCAS.

Handles: web search, article reading, multi-source research reports,
weather, news, fact lookup, Wikipedia-style questions.

Key behaviors:
- Multi-source: searches, reads 2-3 sources, synthesizes into spoken summary
- Spoken output is 2-4 sentences max (TTS-friendly)
- Never reads more than 3 articles per task (respects latency budget)
- Caches results via knowledge.py facts (handled by tool server)
- Weather and news have dedicated fast paths
"""

import re
import logging
from .base_agent import AgentBase, AgentResult, StepRecord

logger = logging.getLogger(__name__)


class ResearchAgent(AgentBase):
    domain_name = "research"

    tool_names = [
        # Core search
        "search_web",
        "read_webpage",
        "smart_search",
        # Browser-based reading (for paywalled/JS content)
        "web_search",
        "web_read_article",
        "web_research",
        # Realtime
        "get_weather",
        "get_news",
        # Memory (cache hits)
        "retrieve_memories",
        "save_memory",
    ]

    @property
    def system_prompt(self) -> str:
        return """You are DEMASCAS's Research Agent — a specialist in web research and information synthesis.

Your responsibilities:
- Web searches and article reading
- Weather and news lookups
- Multi-source research synthesis
- Answering factual questions with current web data

RESEARCH RULES:
1. For simple factual questions: use smart_search first (checks local cache, then Google, then DDG).
2. For weather: use get_weather with the location extracted from the user's goal.
3. For news: use get_news with a topic keyword extracted from the user's goal.
4. For deep research: use web_research which handles multi-source synthesis automatically.
5. NEVER read more than 3 web pages per task — summarize what you find, don't exhaustively read.
6. Your final summary must be 2-4 sentences — it will be spoken aloud by TTS.
7. Don't read the same URL twice. Each read_webpage/web_read_article call should be a unique URL.
8. If a page is paywalled or requires login: skip it and try another source.
9. Prefer recent results (current year) for time-sensitive topics.
10. End every research task with {"done": true, "say": "2-4 sentence spoken summary of findings"}."""

    def _extra_rules(self) -> str:
        return """11. For "what is X": one smart_search call is usually enough — don't chain multiple searches.
12. For "latest news about X": use get_news with topic=X.
13. For "weather in X": use get_weather with location=X.
14. Don't include URLs in the spoken summary — it's for TTS."""

    def run(self, goal: str, context: dict) -> AgentResult:
        goal_lower = goal.lower()

        # Fast-path: weather
        if re.search(r"\b(weather|temperature|forecast|rain|sunny|cloudy)\b", goal_lower):
            return self._weather_flow(goal, context)

        # Fast-path: news
        if re.search(r"\b(news|latest|headlines|what('s| is) happening|today in)\b", goal_lower):
            return self._news_flow(goal, context)

        # Deep research (multi-source)
        if re.search(r"\b(research|investigate|deep dive|find out about|tell me everything)\b", goal_lower):
            return self._deep_research_flow(goal, context)

        # General research
        return self._execute(goal, context)

    # ── Specialized sub-flows ─────────────────────────────────────────────────

    def _weather_flow(self, goal: str, context: dict) -> AgentResult:
        """Direct weather lookup — no LLM needed."""
        location = self._extract_location(goal) or "current location"
        result = self._call_tool("get_weather", {"location": location})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary=f"I couldn't get the weather for {location}.",
                steps_taken=1,
                tool_calls=["get_weather"]
            )
        # Trim for TTS (result may be long)
        spoken = result.strip()[:300]
        return AgentResult(
            success=True,
            summary=spoken,
            steps_taken=1,
            tool_calls=["get_weather"]
        )

    def _news_flow(self, goal: str, context: dict) -> AgentResult:
        """Direct news lookup — extract topic, call get_news."""
        topic = self._extract_news_topic(goal) or "technology"
        result = self._call_tool("get_news", {"topic": topic})
        if self._is_tool_error(result):
            return AgentResult(
                success=False,
                summary=f"I couldn't find news about {topic} right now.",
                steps_taken=1,
                tool_calls=["get_news"]
            )
        spoken = result.strip()[:400]
        return AgentResult(
            success=True,
            summary=spoken,
            steps_taken=1,
            tool_calls=["get_news"]
        )

    def _deep_research_flow(self, goal: str, context: dict) -> AgentResult:
        """
        Multi-source research using web_research tool.
        This tool internally handles search → read → synthesize.
        """
        # Extract the research topic
        topic = re.sub(
            r"\b(research|investigate|find out about|tell me everything about|deep dive into)\b",
            "", goal, flags=re.IGNORECASE
        ).strip()
        topic = topic or goal

        result = self._call_tool("web_research", {"topic": topic, "num_sources": 2})
        if self._is_tool_error(result):
            # Fallback to step loop
            return self._execute(goal, context)

        # Trim to TTS-friendly length
        spoken = result.strip()[:500]
        if len(result) > 500:
            spoken += " I can go deeper on any part of this if you'd like."

        return AgentResult(
            success=True,
            summary=spoken,
            steps_taken=1,
            tool_calls=["web_research"]
        )

    def _on_step_complete(self, record: StepRecord) -> None:
        """After a successful search, note the result for context."""
        if record.tool in ("smart_search", "web_search") and record.success:
            # Store first 200 chars as last_tool_result for next LLM call
            self._active_context["last_tool_result"] = record.result[:200]

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _extract_location(self, goal: str) -> str:
        """Extract location name from 'weather in X' / 'weather for X'."""
        patterns = [
            r"weather\s+(?:in|for|at|near)\s+([A-Za-z\s,]+?)(?:\s*$|\?)",
            r"(?:in|for|at)\s+([A-Za-z\s]+?)\s+(?:weather|forecast|temperature)",
        ]
        for pat in patterns:
            m = re.search(pat, goal, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return ""

    def _extract_news_topic(self, goal: str) -> str:
        """Extract topic from 'news about X' / 'latest on X'."""
        patterns = [
            r"news\s+(?:about|on|regarding)\s+(.+?)(?:\s*$|\?)",
            r"latest\s+(?:on|about|regarding)\s+(.+?)(?:\s*$|\?)",
            r"what('s| is) happening (?:with|in)\s+(.+?)(?:\s*$|\?)",
        ]
        for pat in patterns:
            m = re.search(pat, goal, re.IGNORECASE)
            if m:
                last = m.lastindex or 1
                return m.group(last).strip()
        return ""
